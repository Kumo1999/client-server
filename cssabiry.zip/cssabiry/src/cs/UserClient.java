package cs;
import java.io.*;
import java.net.*;

public class UserClient {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 1234;

        try (Socket socket = new Socket(host, port);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println("Connecté au serveur de gestion des utilisateurs.");
            System.out.println("Commandes disponibles :");
            System.out.println("  add <nom:email>  - Ajouter un utilisateur");
            System.out.println("  list             - Afficher la liste des utilisateurs");
            System.out.println("  remove <id>      - Supprimer un utilisateur");
            System.out.println("  exit             - Quitter");

            String message;
            while (true) {
                System.out.print(">> ");
                message = userInput.readLine();
                out.println(message);

                if ("exit".equalsIgnoreCase(message)) {
                    System.out.println("Déconnexion...");
                    break;
                }

               
                String serverResponse = in.readLine();
                System.out.println(serverResponse);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}