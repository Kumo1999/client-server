package cs;

import java.io.*;
import java.net.*;
import java.util.*;

public class UserServer {
    private static Map<Integer, String> userDatabase = new HashMap<>();
    private static int userIdCounter = 1;

    public static void main(String[] args) {
        int port = 1234;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Serveur de gestion des utilisateurs démarré sur le port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connecté : " + clientSocket.getInetAddress());

                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String clientMessage;
            while ((clientMessage = in.readLine()) != null) {
                String response = processCommand(clientMessage);
                out.println(response);

                if ("exit".equalsIgnoreCase(clientMessage)) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static String processCommand(String command) {
        String[] parts = command.split(" ", 2);
        String action = parts[0].toLowerCase();

        switch (action) {
            case "add":
                if (parts.length < 2) {
                    return "Usage: add <nom:email>";
                }
                String[] userInfo = parts[1].split(":");
                if (userInfo.length < 2) {
                    return "Format invalide. Utilisez nom:email.";
                }
                int id = userIdCounter++;
                userDatabase.put(id, parts[1]);
                return "Utilisateur ajouté avec l'ID : " + id;

            case "list":
                if (userDatabase.isEmpty()) {
                    return "Aucun utilisateur enregistré.";
                }
                StringBuilder list = new StringBuilder("Liste des utilisateurs :\n");
                for (Map.Entry<Integer, String> entry : userDatabase.entrySet()) {
                    list.append("ID: ").append(entry.getKey())
                        .append(", Info: ").append(entry.getValue()).append("\n");
                }
                return list.toString();

            case "remove":
                if (parts.length < 2) {
                    return "Usage: remove <id>";
                }
                try {
                    int removeId = Integer.parseInt(parts[1]);
                    if (userDatabase.remove(removeId) != null) {
                        return "Utilisateur avec l'ID " + removeId + " supprimé.";
                    } else {
                        return "Utilisateur non trouvé.";
                    }
                } catch (NumberFormatException e) {
                    return "L'ID doit être un entier.";
                }

            case "exit":
                return "Déconnexion...";

            default:
                return "Commandes disponibles : add, list, remove, exit";
        }
    }
}